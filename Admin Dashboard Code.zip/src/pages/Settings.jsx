import React, { useState, useEffect, useCallback } from "react";
import {
  Typography,
  FormControlLabel,
  Switch,
  Select,
  MenuItem,
  Box,
  Paper,
  InputLabel, 
  FormControl, 
  FormHelperText,
  Button,
} from "@mui/material";

// Define possible color themes
const availableThemes = [
    { code: "default", name: "System Default" },
    { code: "blue", name: "Ocean Blue" },
    { code: "green", name: "Forest Green" },
  ];

  // Define font sizes
  const fontSizes = [
    { code: "small", name: "Small" },
    { code: "medium", name: "Medium" },
    { code: "large", name: "Large" },
  ];

  // Define items per page options
  const itemsPerPageOptions = [10, 25, 50, 100];

  // Define report view options
  const reportViewOptions = [
    { code: "newest", name: "Newest First" },
    { code: "oldest", name: "Oldest First" },
    { code: "urgency", name: "By Urgency" },
    { code: "status", name: "By Status" },
  ];

  // Define export formats
  const exportFormats = [
    { code: "csv", name: "CSV" },
    { code: "pdf", name: "PDF" },
    { code: "json", name: "JSON" },
  ];


export default function Settings({ setThemeColor }) {
  
  // Initial State: Retrieve from localStorage
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem("themeColor") || "default";
  });

  const [validationError, setValidationError] = useState("");

  const [fontSize, setFontSize] = useState(() => {
    return localStorage.getItem("fontSize") || "medium";
  });

  const [itemsPerPage, setItemsPerPage] = useState(() => {
    return parseInt(localStorage.getItem("itemsPerPage")) || 25;
  });

  const [reportView, setReportView] = useState(() => {
    return localStorage.getItem("reportView") || "newest";
  });

  const [exportFormat, setExportFormat] = useState(() => {
    return localStorage.getItem("exportFormat") || "csv";
  });

  // Combined and Memoized Save Handler
  const savePreferences = useCallback((key, value) => {
      setValidationError(""); 
      localStorage.setItem(key, value);
      // Dispatch a global event so other parts of the SPA update instantly
      try {
        window.dispatchEvent(new CustomEvent('app-settings-changed', { detail: { key, value } }));
      } catch (e) {
        // noop in non-browser or if CustomEvent is restricted
      }
  }, []); 

  // Effect Hooks: Save and apply preferences when state changes

  useEffect(() => {
    savePreferences("themeColor", theme);
    // Call the function passed from the parent component (App.jsx)
    if (setThemeColor) {
        setThemeColor(theme); 
    }
  }, [theme, savePreferences, setThemeColor]);

  useEffect(() => {
    savePreferences("fontSize", fontSize);
  }, [fontSize, savePreferences]);

  // Apply font size immediately to document root so UI updates
  useEffect(() => {
    const map = { small: '14px', medium: '16px', large: '18px' };
    const size = map[fontSize] || map.medium;
    try {
      document.documentElement.style.fontSize = size;
    } catch (e) {
      // noop in non-browser environments
    }
  }, [fontSize]);

  useEffect(() => {
    savePreferences("itemsPerPage", itemsPerPage.toString());
  }, [itemsPerPage, savePreferences]);

  useEffect(() => {
    savePreferences("reportView", reportView);
  }, [reportView, savePreferences]);

  useEffect(() => {
    savePreferences("exportFormat", exportFormat);
  }, [exportFormat, savePreferences]);

  // Clear cache handler
  const handleClearCache = () => {
    localStorage.clear();
    setTheme("default");
    setFontSize("medium");
    setItemsPerPage(25);
    setReportView("newest");
    setExportFormat("csv");
    alert("Cache cleared successfully!");
    try {
      window.dispatchEvent(new CustomEvent('app-settings-changed', { detail: { cleared: true } }));
    } catch (e) {}
  };


  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h4" gutterBottom>
        User Preferences ⚙️
      </Typography>
      <Paper sx={{ p: 3, maxWidth: 450, borderRadius: 2 }}>
        
        {/* === Display Settings === */}
        <Typography variant="h6" sx={{ mb: 1.5, borderBottom: '1px solid #eee', pb: 0.5 }}>
            Display
        </Typography>

        <Box sx={{ mt: 2, mb: 3 }}>
            <FormControl fullWidth>
                <InputLabel id="theme-select-label">Color Theme</InputLabel>
                <Select
                    labelId="theme-select-label"
                    value={theme}
                    label="Color Theme"
                    onChange={(e) => setTheme(e.target.value)} // Updates the theme state
                >
                    {availableThemes.map(t => (
                        <MenuItem key={t.code} value={t.code}>{t.name}</MenuItem>
                    ))}
                </Select>
                <FormHelperText>Select a primary color scheme for the application.</FormHelperText>
            </FormControl>
        </Box>

          <Box sx={{ mt: 2, mb: 3 }}>
            <FormControl fullWidth>
              <InputLabel id="font-size-label">Font Size</InputLabel>
              <Select
                labelId="font-size-label"
                value={fontSize}
                label="Font Size"
                onChange={(e) => setFontSize(e.target.value)}
              >
                {fontSizes.map(f => (
                  <MenuItem key={f.code} value={f.code}>{f.name}</MenuItem>
                ))}
              </Select>
              <FormHelperText>Adjust text size for better readability.</FormHelperText>
            </FormControl>
          </Box>

          {/* === Report Settings === */}
          <Typography variant="h6" sx={{ mb: 1.5, borderBottom: '1px solid #eee', pb: 0.5, mt: 3 }}>
            Report Settings
          </Typography>

          <Box sx={{ mt: 2, mb: 3 }}>
            <FormControl fullWidth>
              <InputLabel id="items-per-page-label">Items Per Page</InputLabel>
              <Select
                labelId="items-per-page-label"
                value={itemsPerPage}
                label="Items Per Page"
                onChange={(e) => setItemsPerPage(Number(e.target.value))}
              >
                {itemsPerPageOptions.map(option => (
                  <MenuItem key={option} value={option}>{option}</MenuItem>
                ))}
              </Select>
              <FormHelperText>Set the number of reports displayed per page.</FormHelperText>
            </FormControl>
          </Box>

          <Box sx={{ mt: 2, mb: 3 }}>
            <FormControl fullWidth>
              <InputLabel id="report-view-label">Default Report View</InputLabel>
              <Select
                labelId="report-view-label"
                value={reportView}
                label="Default Report View"
                onChange={(e) => setReportView(e.target.value)}
              >
                {reportViewOptions.map(option => (
                  <MenuItem key={option.code} value={option.code}>{option.name}</MenuItem>
                ))}
              </Select>
              <FormHelperText>Choose the default sorting for reports.</FormHelperText>
            </FormControl>
          </Box>

          <Box sx={{ mt: 2, mb: 3 }}>
            <FormControl fullWidth>
              <InputLabel id="export-format-label">Export Format</InputLabel>
              <Select
                labelId="export-format-label"
                value={exportFormat}
                label="Export Format"
                onChange={(e) => setExportFormat(e.target.value)}
              >
                {exportFormats.map(format => (
                  <MenuItem key={format.code} value={format.code}>{format.name}</MenuItem>
                ))}
              </Select>
              <FormHelperText>Select your preferred format for exporting reports.</FormHelperText>
            </FormControl>
          </Box>

          {/* === Data Management === */}
          <Typography variant="h6" sx={{ mb: 1.5, borderBottom: '1px solid #eee', pb: 0.5, mt: 3 }}>
            Data Management
          </Typography>

          <Button 
            variant="outlined" 
            color="error"
            onClick={handleClearCache}
            fullWidth
            sx={{ mt: 2 }}
          >
            Clear Cache
          </Button>
          <FormHelperText sx={{ mt: 1, textAlign: 'center' }}>
            This will reset all settings to their default values.
          </FormHelperText>
      </Paper>
    </Box>
  );
}