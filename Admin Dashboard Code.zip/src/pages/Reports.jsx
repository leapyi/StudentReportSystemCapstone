import React, { useState, useEffect, useMemo } from "react";
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Avatar,
  Modal,
  IconButton,
  Tooltip,
  Collapse,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Stack,
  Button,
  Pagination,
} from "@mui/material";
import { DeleteOutline, KeyboardArrowDown, KeyboardArrowUp } from '@mui/icons-material';
import { useReportsData } from '../reports';
import { db } from '../firebase';
import { doc, deleteDoc, updateDoc, collection, addDoc, serverTimestamp } from "firebase/firestore";

const urgencyColors = {
  High: "error",
  Medium: "warning",
  Low: "success",
};

const statusColors = {
  Pending: "#ffcdd2",
  "In Progress": "#ffe0b2",
  Resolved: "#c8e6c9",
};

const logActivity = async (reportId, type, description) => {
  try {
    await addDoc(collection(db, 'report_activities'), {
      reportId,
      type,
      description,
      timestamp: serverTimestamp()
    });
  } catch (error) {
    console.error('Error logging activity:', error);
  }
};

function Row(props) {
  const { report, handleDelete, handleOpenImageModal, handleStatusChange } = props;
  const [open, setOpen] = useState(false);

  const handleToggleCollapse = (e) => {
    e.stopPropagation();
    setOpen(!open);
  };

  const handleImageClick = (e) => {
    e.stopPropagation();
    handleOpenImageModal(report.attachmentUrl);
  };

  const handleDeleteClick = (e, reportId) => {
    e.stopPropagation();
    handleDelete(reportId);
  };

  const handleStatusClick = (e) => {
    e.stopPropagation();
  };

  return (
    <React.Fragment>
      <TableRow
        sx={{
          '& > *': { borderBottom: 'unset' },
          backgroundColor: statusColors[report.status] || statusColors['Pending']
        }}
        onClick={() => setOpen(!open)}
        style={{ cursor: 'pointer' }}
      >
        <TableCell>
          <IconButton
            aria-label="expand row"
            size="small"
            onClick={handleToggleCollapse}
          >
            {open ? <KeyboardArrowUp /> : <KeyboardArrowDown />}
          </IconButton>
        </TableCell>
        <TableCell>{report.category}</TableCell>
        <TableCell>{report.description}</TableCell>
        <TableCell>
          <Chip
            label={report.urgency}
            color={urgencyColors[report.urgency] || "default"}
            size="small"
          />
        </TableCell>
        <TableCell>
          {report.attachmentUrl && (
            <Avatar
              alt="Attachment"
              src={report.attachmentUrl}
              sx={{ width: 50, height: 50, cursor: 'zoom-in' }}
              onClick={handleImageClick}
            />
          )}
        </TableCell>
        <TableCell>{report.studentId || "N/A"}</TableCell>
        <TableCell>{report.email || "N/A"}</TableCell>
        <TableCell onClick={handleStatusClick}>
          <FormControl size="small">
            <Select
              value={report.status || 'Pending'}
              onChange={(e) => handleStatusChange(report.id, e.target.value)}
              sx={{ minWidth: 120 }}
            >
              <MenuItem value="Pending">Pending</MenuItem>
              <MenuItem value="In Progress">In Progress</MenuItem>
              <MenuItem value="Resolved">Resolved</MenuItem>
            </Select>
          </FormControl>
        </TableCell>
        <TableCell>
          <Tooltip title="Delete Report">
            <IconButton
              color="error"
              aria-label="delete"
              onClick={(e) => handleDeleteClick(e, report.id)}
            >
              <DeleteOutline />
            </IconButton>
          </Tooltip>
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={10}>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <Box sx={{ margin: 1 }}>
              <Typography variant="h6" gutterBottom component="div">
                Details
              </Typography>
              <Typography variant="body2">
                <strong>Anonymous:</strong> {report.anonymous ? 'Yes' : 'No'}
              </Typography>
              <Typography variant="body2">
                <strong>Email:</strong> {report.email || 'N/A'}
              </Typography>
              <Typography variant="body2">
                <strong>Attachment File Name:</strong> {report.attachmentFileName || 'N/A'}
              </Typography>
              <Typography variant="body2">
                <strong>Timestamp:</strong> {report.timestamp?.toDate().toLocaleString('en-PH', {
                  timeZone: 'Asia/Manila',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit',
                  hour12: true
                }) || 'N/A'}
              </Typography>
              <Typography variant="body2">
                <strong>Status:</strong> {report.status || 'Pending'}
              </Typography>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </React.Fragment>
  );
}

export default function Reports() {
  const { reports, isLoading, error } = useReportsData();
  const [statusFilter, setStatusFilter] = useState('All');
  const [urgencyFilter, setUrgencyFilter] = useState('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [itemsPerPageSetting, setItemsPerPageSetting] = useState(() => {
    const v = parseInt(localStorage.getItem('itemsPerPage'));
    return Number.isNaN(v) ? 25 : v;
  });
  const [reportViewSetting, setReportViewSetting] = useState(() => {
    return localStorage.getItem('reportView') || 'newest';
  });
  const [exportFormatSetting, setExportFormatSetting] = useState(() => {
    return localStorage.getItem('exportFormat') || 'csv';
  });
  const [page, setPage] = useState(1);

  const handleOpenImageModal = (imageUrl) => {
    if (imageUrl) {
      setSelectedImage(imageUrl);
      setIsModalOpen(true);
    } else {
      console.warn("Attempted to open image modal with a null or empty URL.");
    }
  };

  const handleClose = () => {
    setIsModalOpen(false);
    setSelectedImage(null);
  };

  const handleDelete = async (reportId) => {
    try {
      const reportRef = doc(db, "reports", reportId);
      await deleteDoc(reportRef);
      await logActivity(
        reportId,
        'deleted',
        `Report ${reportId} was deleted`
      );
    } catch (error) {
      console.error("Error deleting report: ", error);
    }
  };

  const handleStatusChange = async (reportId, newStatus) => {
    try {
      const reportRef = doc(db, "reports", reportId);
      await updateDoc(reportRef, {
        status: newStatus
      });
      await logActivity(
        reportId,
        'status_change',
        `Report status changed to ${newStatus}`
      );
    } catch (error) {
      console.error("Error updating report status: ", error);
    }
  };

  // Listen for storage changes from Settings (other tabs) so settings update dynamically
  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'itemsPerPage') {
        const v = parseInt(e.newValue);
        setItemsPerPageSetting(Number.isNaN(v) ? 25 : v);
      }
      if (e.key === 'reportView') {
        setReportViewSetting(e.newValue || 'newest');
      }
      if (e.key === 'exportFormat') {
        setExportFormatSetting(e.newValue || 'csv');
      }
    };
    window.addEventListener('storage', handler);
    return () => window.removeEventListener('storage', handler);
  }, []);

  // Listen for in-app settings changes dispatched by Settings.jsx
  useEffect(() => {
    const handler = (event) => {
      const detail = event?.detail || {};
      if (detail.cleared) {
        setItemsPerPageSetting(25);
        setReportViewSetting('newest');
        setExportFormatSetting('csv');
        setPage(1);
        return;
      }
      const { key, value } = detail;
      if (!key) return;
      if (key === 'itemsPerPage') {
        const v = parseInt(value);
        setItemsPerPageSetting(Number.isNaN(v) ? 25 : v);
      }
      if (key === 'reportView') {
        setReportViewSetting(value || 'newest');
      }
      if (key === 'exportFormat') {
        setExportFormatSetting(value || 'csv');
      }
      // reset to first page when settings change
      setPage(1);
    };
    window.addEventListener('app-settings-changed', handler);
    return () => window.removeEventListener('app-settings-changed', handler);
  }, []);

  // Export handler (CSV / JSON / PDF via dynamic import)
  const handleExport = async () => {
    const format = exportFormatSetting;
    // Export ALL filtered/sorted reports, not just the current page
    const data = sortedReports.map(r => ({
      id: r.id,
      category: r.category,
      description: r.description,
      urgency: r.urgency,
      status: r.status,
      studentId: r.studentId,
      email: r.email,
      timestamp: r.timestamp?.toDate?.()?.toISOString?.() || ''
    }));

    if (format === 'json') {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'reports.json';
      a.click();
      URL.revokeObjectURL(url);
      return;
    }

    if (format === 'csv') {
      const keys = Object.keys(data[0] || {});
      const csv = [keys.join(',')].concat(data.map(row => keys.map(k => `"${(row[k]||'').toString().replace(/"/g,'""')}"`).join(','))).join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'reports.csv';
      a.click();
      URL.revokeObjectURL(url);
      return;
    }

    if (format === 'pdf') {
      try {
        const mod = await import('jspdf');
        const { jsPDF } = mod;
        await import('jspdf-autotable');
        
        const doc = new jsPDF({ unit: 'mm', format: 'a4' });
        doc.setFontSize(16);
        doc.text('Reports Export', 14, 15);
        doc.setFontSize(10);
        doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 22);
        
        // Prepare table data
        const tableHeaders = ['ID', 'Category', 'Description', 'Urgency', 'Status', 'Student ID', 'Email'];
        const tableData = data.map(row => [
          row.id || '',
          row.category || '',
          (row.description || '').slice(0, 50),
          row.urgency || '',
          row.status || '',
          row.studentId || '',
          row.email || ''
        ]);
        
        // Use autoTable to create a formatted table
        doc.autoTable({
          head: [tableHeaders],
          body: tableData,
          startY: 28,
          margin: { top: 28, right: 10, bottom: 10, left: 10 },
          columnStyles: {
            0: { cellWidth: 15 },
            1: { cellWidth: 18 },
            2: { cellWidth: 35 },
            3: { cellWidth: 15 },
            4: { cellWidth: 18 },
            5: { cellWidth: 20 },
            6: { cellWidth: 25 }
          },
          headStyles: {
            fillColor: [41, 128, 185],
            textColor: [255, 255, 255],
            fontStyle: 'bold',
            fontSize: 10
          },
          bodyStyles: {
            fontSize: 9
          },
          alternateRowStyles: {
            fillColor: [240, 240, 240]
          },
          didDrawPage: (data) => {
            // Footer
            doc.setFontSize(8);
            doc.text(`Page ${data.pageNumber}`, 100, doc.internal.pageSize.getHeight() - 7);
          }
        });
        
        doc.save('reports.pdf');
      } catch (err) {
        console.error('PDF export failed:', err);
        alert('PDF export failed. Downloading JSON instead.');
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'reports.json';
        a.click();
        URL.revokeObjectURL(url);
      }
    }

  };

  const filteredReports = reports.filter(report => {
    const statusMatch = statusFilter === 'All' || report.status === statusFilter || (!report.status && statusFilter === 'Pending');
    const urgencyMatch = urgencyFilter === 'All' || report.urgency === urgencyFilter;
    return statusMatch && urgencyMatch;
  });

  // Sort according to reportViewSetting
  const sortedReports = useMemo(() => {
    const arr = [...filteredReports];
    if (reportViewSetting === 'newest') {
      arr.sort((a, b) => (b.timestamp?.toDate?.() || 0) - (a.timestamp?.toDate?.() || 0));
    } else if (reportViewSetting === 'oldest') {
      arr.sort((a, b) => (a.timestamp?.toDate?.() || 0) - (b.timestamp?.toDate?.() || 0));
    } else if (reportViewSetting === 'urgency') {
      const order = { High: 0, Low: 1, Medium: 2 };
      arr.sort((a, b) => (order[a.urgency] || 3) - (order[b.urgency] || 3));
    } else if (reportViewSetting === 'status') {
      const order = { Pending: 0, 'In Progress': 1, Resolved: 2 };
      arr.sort((a, b) => (order[a.status] || 3) - (order[b.status] || 3));
    }
    return arr;
  }, [filteredReports, reportViewSetting]);

  const totalPages = Math.max(1, Math.ceil(sortedReports.length / itemsPerPageSetting));
  const pagedReports = useMemo(() => {
    const start = (page - 1) * itemsPerPageSetting;
    return sortedReports.slice(start, start + itemsPerPageSetting);
  }, [sortedReports, page, itemsPerPageSetting]);

  if (isLoading) {
    return <Typography>Loading reports...</Typography>;
  }

  if (error) {
    return <Typography color="error">Error: {error.message}</Typography>;
  }

  return (
    <Box sx={{ p: 3, mt: 8 }}>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Reports
      </Typography>

      <Stack direction="row" spacing={2} sx={{ mb: 3 }}>
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Filter by Status</InputLabel>
          <Select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            label="Filter by Status"
          >
            <MenuItem value="All">All Status</MenuItem>
            <MenuItem value="Pending">Pending</MenuItem>
            <MenuItem value="In Progress">In Progress</MenuItem>
            <MenuItem value="Resolved">Resolved</MenuItem>
          </Select>
        </FormControl>

        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Filter by Urgency</InputLabel>
          <Select
            value={urgencyFilter}
            onChange={(e) => setUrgencyFilter(e.target.value)}
            label="Filter by Urgency"
          >
            <MenuItem value="All">All Urgency</MenuItem>
            <MenuItem value="High">High</MenuItem>
            <MenuItem value="Medium">Medium</MenuItem>
            <MenuItem value="Low">Low</MenuItem>
          </Select>
        </FormControl>
      </Stack>

<TableContainer component={Paper} elevation={3}>
        <Table aria-label="collapsible table">
          <TableHead sx={{ backgroundColor: "#f5f5f5" }}>
            <TableRow>
              <TableCell />
              <TableCell><strong>Category</strong></TableCell>
              <TableCell><strong>Description</strong></TableCell>
              <TableCell><strong>Urgency</strong></TableCell>
              <TableCell><strong>Attachment</strong></TableCell>
              <TableCell><strong>Student ID</strong></TableCell>
              <TableCell><strong>Email</strong></TableCell>
              <TableCell><strong>Status</strong></TableCell>
              <TableCell><strong>Actions</strong></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {pagedReports.map((report) => (
              <Row
                key={report.id}
                report={report}
                handleDelete={handleDelete}
                handleOpenImageModal={handleOpenImageModal}
                handleStatusChange={handleStatusChange}
              />
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Modal
        open={isModalOpen}
        onClose={handleClose}
        aria-labelledby="image-modal"
        aria-describedby="image-modal-description"
      >
        <Box sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '80%',
          maxWidth: 800,
          bgcolor: 'background.paper',
          border: '2px solid #000',
          boxShadow: 24,
          p: 4,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
          <img
            src={selectedImage}
            alt="Expanded Attachment"
            style={{ maxWidth: '100%', maxHeight: '80vh', display: 'block' }}
          />
        </Box>
      </Modal>

      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
        <Stack direction="row" spacing={2}>
          <Button variant="outlined" onClick={() => {
            // refresh settings from localStorage
            setItemsPerPageSetting(() => {
              const v = parseInt(localStorage.getItem('itemsPerPage'));
              return Number.isNaN(v) ? 25 : v;
            });
            setReportViewSetting(localStorage.getItem('reportView') || 'newest');
            setExportFormatSetting(localStorage.getItem('exportFormat') || 'csv');
            setPage(1);
          }}>
            Refresh Settings
          </Button>
          <Button variant="contained" onClick={() => handleExport()}>
            Export ({exportFormatSetting.toUpperCase()})
          </Button>
        </Stack>

        <Pagination count={totalPages} page={page} onChange={(_, val) => setPage(val)} color="primary" />
      </Box>
    </Box>
  );
}