import React, { useState, useEffect } from "react";
import {
  Typography,
  Box,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Divider,
  CircularProgress
} from "@mui/material";
import {
  CheckCircleOutline,
  ErrorOutline,
  HourglassEmpty,
  Delete
} from '@mui/icons-material';
import { db } from '../firebase';
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore';

const actionIcons = {
  'status_change': HourglassEmpty,
  'resolved': CheckCircleOutline,
  'deleted': Delete,
  'created': ErrorOutline
};

const actionColors = {
  'status_change': 'primary',
  'resolved': 'success',
  'deleted': 'error',
  'created': 'warning'
};

export default function ReportHistory() {
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchActivities = async () => {
      try {
        const q = query(
          collection(db, 'report_activities'),
          orderBy('timestamp', 'desc'),
          limit(50)
        );
        
        const querySnapshot = await getDocs(q);
        const activityList = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        
        setActivities(activityList);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching activities:', err);
        setError('Failed to load activity history');
        setLoading(false);
      }
    };

    fetchActivities();
  }, []);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3, mt: 8 }}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3, mt: 8 }}>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Report Activity History
      </Typography>

      <Paper sx={{ mt: 3 }}>
        <List>
          {activities.map((activity, index) => {
            const IconComponent = actionIcons[activity.type] || HourglassEmpty;
            
            return (
              <React.Fragment key={activity.id}>
                <ListItem>
                  <ListItemIcon>
                    <IconComponent color={actionColors[activity.type]} />
                  </ListItemIcon>
                  <ListItemText
                    primary={
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                        <Typography variant="body1">
                          {activity.description}
                        </Typography>
                        <Chip
                          label={activity.type.replace('_', ' ')}
                          size="small"
                          color={actionColors[activity.type]}
                        />
                      </Box>
                    }
                    secondary={
                      <>
                        <Typography component="span" variant="body2" color="text.primary">
                          Report ID: {activity.reportId}
                        </Typography>
                        {' — '}
                        {activity.timestamp?.toDate().toLocaleString()}
                      </>
                    }
                  />
                </ListItem>
                {index < activities.length - 1 && <Divider />}
              </React.Fragment>
            );
          })}
        </List>
      </Paper>
    </Box>
  );
}
