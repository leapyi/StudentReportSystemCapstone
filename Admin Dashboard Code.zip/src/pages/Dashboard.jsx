import React, { useState, useEffect } from "react";
import {
  Typography,
  Box,
  Paper,
  Grid,
  CircularProgress,
  Card,
  CardContent,
  Divider,
} from "@mui/material";
import { db } from '../firebase';
import { collection, query, getDocs } from 'firebase/firestore';

export default function ReportsSummary() {
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    inProgress: 0,
    resolved: 0,
    highUrgency: 0,
    anonymous: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const reportsQuery = query(collection(db, 'reports'));
        const querySnapshot = await getDocs(reportsQuery);
        
        const statistics = {
          total: 0,
          pending: 0,
          inProgress: 0,
          resolved: 0,
          highUrgency: 0,
          anonymous: 0,
        };

        querySnapshot.forEach((doc) => {
          const report = doc.data();
          statistics.total++;

          // Count by status
          switch(report.status) {
            case 'Pending':
              statistics.pending++;
              break;
            case 'In Progress':
              statistics.inProgress++;
              break;
            case 'Resolved':
              statistics.resolved++;
              break;
            default:
              statistics.pending++; // Default to pending if no status
          }

          // Count high urgency reports
          if (report.urgency === 'High') {
            statistics.highUrgency++;
          }

          // Count anonymous reports
          if (report.anonymous) {
            statistics.anonymous++;
          }
        });

        setStats(statistics);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching report statistics:', err);
        setError('Failed to load report statistics');
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3, mt: 8 }}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3, mt: 8 }}>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Reports Summary
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={3}>
          <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <CardContent sx={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <Typography variant="h6" gutterBottom>
                Total Reports
              </Typography>
              <Typography variant="h3" color="primary">
                {stats.total}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <CardContent sx={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <Typography variant="h6" gutterBottom>
                Pending
              </Typography>
              <Typography variant="h3" color="error">
                {stats.pending}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <CardContent sx={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <Typography variant="h6" gutterBottom>
                In Progress
              </Typography>
              <Typography variant="h3" color="warning.main">
                {stats.inProgress}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <CardContent sx={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <Typography variant="h6" gutterBottom>
                Resolved
              </Typography>
              <Typography variant="h3" color="success.main">
                {stats.resolved}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <CardContent sx={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <Typography variant="h6" gutterBottom>
                High Urgency Reports
              </Typography>
              <Typography variant="h3" color="error">
                {stats.highUrgency}
              </Typography>
              <Typography variant="caption" color="textSecondary">
                {((stats.highUrgency / stats.total) * 100).toFixed(1)}% of total
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <CardContent sx={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <Typography variant="h6" gutterBottom>
                Anonymous Reports
              </Typography>
              <Typography variant="h3" color="info.main">
                {stats.anonymous}
              </Typography>
              <Typography variant="caption" color="textSecondary">
                {((stats.anonymous / stats.total) * 100).toFixed(1)}% of total
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}