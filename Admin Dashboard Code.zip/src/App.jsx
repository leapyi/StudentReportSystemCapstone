import React, { useState, useMemo } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { CssBaseline, Box, createTheme, ThemeProvider } from "@mui/material";

// Import your components
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import Reports from "./pages/Reports";
import Inbox from "./pages/Inbox";
import Settings from "./pages/Settings";

// Theme utility function to create the MUI theme object with complementary backgrounds
const getAppTheme = (themeCode, isDarkMode) => {
  let paletteSettings = {};

  // 1. Define Primary Color and Light Mode Backgrounds
  switch (themeCode) {
    case 'blue':
      paletteSettings.primary = { main: '#2196f3' }; // Ocean Blue
      if (!isDarkMode) {
        paletteSettings.background = { 
          default: '#F5F9FD', // Very light blue-tinted background
          paper: '#FFFFFF'    // Pure white for card/paper elements
        };
      }
      break;
    case 'green':
      paletteSettings.primary = { main: '#4caf50' }; // Forest Green
      if (!isDarkMode) {
        paletteSettings.background = { 
          default: '#F7FFF7', // Very light green-tinted background
          paper: '#FFFFFF'
        };
      }
      break;
    case 'default':
    default:
      // Use MUI's standard primary color for the default theme
      paletteSettings.primary = { 
          main: isDarkMode ? '#90caf9' : '#1976d2' 
      }; 
      break;
  }

  // 2. Return the complete theme object
  return createTheme({
    palette: {
      // Set the color mode
      mode: isDarkMode ? 'dark' : 'light',
      
      // Override dark mode background for consistency regardless of themeCode
      ...(isDarkMode && {
        background: {
          default: '#121212', // Standard dark background
          paper: '#1e1e1e',    // Slightly lighter dark for Paper/Cards
        },
      }),

      // Spread the primary color and any custom light-mode backgrounds
      ...paletteSettings, 
    },
  });
};


export default function App() {
  // Load saved dark mode setting
  const savedDarkMode = localStorage.getItem("darkMode") === "true";
  const [darkMode, setDarkMode] = useState(savedDarkMode);

  // Load saved theme color setting
  const savedThemeColor = localStorage.getItem("themeColor") || "default";
  const [themeColor, setThemeColor] = useState(savedThemeColor);


  // Generate the theme object, recalculating only when themeColor or darkMode changes
  const theme = useMemo(
    () => getAppTheme(themeColor, darkMode),
    [darkMode, themeColor] 
  );

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Box sx={{ display: "flex" }}>
          <Navbar />
          <Sidebar />
          <Box 
            component="main" 
            sx={{ flexGrow: 1, p: 3, pt: { xs: 10, sm: 12 } }} // Padding to clear the Navbar
          >
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/inbox" element={<Inbox />} />
              <Route
                path="/settings"
                element={
                  <Settings 
                    darkMode={darkMode} 
                    setDarkMode={setDarkMode} 
                    setThemeColor={setThemeColor} // Passed to update the global color state
                  />
                }
              />
            </Routes>
          </Box>
        </Box>
      </Router>
    </ThemeProvider>
  );
}