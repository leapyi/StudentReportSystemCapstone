import { db } from './firebase';
import { collection, onSnapshot } from "firebase/firestore";
import React from 'react'; // Import React

export function useReportsData() {
  const [reports, setReports] = React.useState([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [error, setError] = React.useState(null);

  React.useEffect(() => {
    const unsubscribe = onSnapshot(
      collection(db, 'reports'),
      (snapshot) => {
        const reportList = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        }));
        setReports(reportList);
        setIsLoading(false);
      },
      (error) => {
        setError(error);
        setIsLoading(false);
      }
    );

    return () => unsubscribe(); // Unsubscribe on unmount
  }, []);

  return { reports, isLoading, error };
}