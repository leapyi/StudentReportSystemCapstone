// src/firebase.js
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyB9KAy86StaPVqxdjkYJ9yykULE25KhA8c",
  authDomain: "report-system-capstone.firebaseapp.com",
  projectId: "report-system-capstone",
  storageBucket: "report-system-capstone.firebasestorage.app",
  messagingSenderId: "1046817825401",
  appId: "1:1046817825401:web:10740b14eacfb5ffe2aaa8",
  measurementId: "G-JRHL82E4CB"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };
