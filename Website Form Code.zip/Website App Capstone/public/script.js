// script.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing...');
    const form = document.getElementById('reportForm');
    const submitBtn = document.getElementById('submitBtn');
    const snackbar = document.getElementById('snackbar');

    // Set button to initially disabled
    submitBtn.disabled = true;

    // Uncheck all urgency radio buttons on load
    const urgencyRadios = form.querySelectorAll('input[name="urgency"]');
    urgencyRadios.forEach(radio => {
        radio.checked = false;
    });

    // Get all form inputs
    const formInputs = form.querySelectorAll('input[type="text"], input[type="email"], textarea, input[name="urgency"]');

    // Add event listeners to all form inputs to check validity
    formInputs.forEach(input => {
        input.addEventListener('change', validateForm);
        input.addEventListener('input', validateForm);
    });

    // Validate form on initial load
    validateForm();

    function validateForm() {
        const category = document.getElementById('category').value.trim();
        const description = document.getElementById('description').value.trim();
        const studentId = document.getElementById('studentId').value.trim();
        const urgency = document.querySelector('input[name="urgency"]:checked');

        // Enable submit button only if all required fields are filled
        if (category && description && studentId && urgency) {
            submitBtn.disabled = false;
            submitBtn.style.opacity = '1';
            submitBtn.style.cursor = 'pointer';
        } else {
            submitBtn.disabled = true;
            submitBtn.style.opacity = '0.5';
            submitBtn.style.cursor = 'not-allowed';
        }
    }

    // Form submission
    form.addEventListener('submit', async function(event) {
        event.preventDefault();
        console.log('Form submitted');

        const category = document.getElementById('category').value.trim();
        const description = document.getElementById('description').value.trim();
        const studentId = document.getElementById('studentId').value.trim();
        const email = document.getElementById('email').value.trim() || null;
        const urgency = document.querySelector('input[name="urgency"]:checked').value;

        console.log('Form data:', { category, description, studentId, email, urgency });

        // Show confirmation modal
        showConfirmationModal(category, description, studentId, email, urgency);
    });

    function showConfirmationModal(category, description, studentId, email, urgency) {
        // Create modal overlay
        const modal = document.createElement('div');
        modal.id = 'confirmationModal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        `;

        // Create modal content
        const modalContent = document.createElement('div');
        modalContent.style.cssText = `
            background-color: white;
            border-radius: 8px;
            padding: 30px;
            max-width: 500px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            animation: slideIn 0.3s ease-out;
        `;

        // Add animation to style
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateY(-50px);
                    opacity: 0;
                }
                to {
                    transform: translateY(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);

        // Add content
        modalContent.innerHTML = `
            <h2 style="margin-top: 0; color: #333;">Confirm Submission</h2>
            <p style="color: #666; margin-bottom: 20px;">Please review your information before submitting:</p>
            <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                <p><strong>Category:</strong> ${escapeHtml(category)}</p>
                <p><strong>Student ID:</strong> ${escapeHtml(studentId)}</p>
                <p><strong>Description:</strong> ${escapeHtml(description)}</p>
                <p><strong>Email:</strong> ${email ? escapeHtml(email) : 'Not provided'}</p>
                <p><strong>Urgency:</strong> ${escapeHtml(urgency)}</p>
            </div>
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                <button id="cancelBtn" style="padding: 10px 20px; background-color: #ff6b6b; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: 500;">Cancel</button>
                <button id="confirmBtn" style="padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer;">Submit</button>
            </div>
        `;

        modal.appendChild(modalContent);
        document.body.appendChild(modal);

        // Handle cancel button
        document.getElementById('cancelBtn').addEventListener('click', () => {
            modal.remove();
        });

        // Handle confirm button
        document.getElementById('confirmBtn').addEventListener('click', async () => {
            modal.remove();
            submitBtn.disabled = true;
            submitBtn.textContent = 'Submitting...';

            try {
                await saveReport(category, description, false, studentId, email, urgency, null, null);
            } catch (error) {
                console.error('Error in form submission:', error);
                showSnackbar('Error submitting report: ' + error.message, 'error');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Submit Report';
                validateForm();
            }
        });
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    async function saveReport(category, description, isAnonymous, studentId, email, urgency, attachmentUrl, attachmentFileName) {
        console.log('Saving report to Firestore...');
        const reportData = {
            category,
            description,
            isAnonymous: false, // Always identified
            studentId,
            email,
            urgency,
            attachmentFileName,
            attachmentUrl,
            timestamp: firebase.firestore.Timestamp.now()
        };
        console.log('Report data:', reportData);

        try {
            console.log('window.db:', window.db);
            const docRef = await window.db.collection('reports').add(reportData);
            console.log('Report saved with ID:', docRef.id);
            showSnackbar('Report submitted successfully!', 'success');
            form.reset();
            validateForm();
        } catch (error) {
            console.error('Firestore error:', error);
            showSnackbar('Error saving report: ' + error.message, 'error');
            throw error;
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Submit Report';
        }
    }

    function showSnackbar(message, type = 'info') {
        snackbar.textContent = message;
        snackbar.className = 'show';
        if (type === 'error') {
            snackbar.style.backgroundColor = '#f44336';
        } else if (type === 'success') {
            snackbar.style.backgroundColor = '#4CAF50';
        } else {
            snackbar.style.backgroundColor = '#333';
        }
        setTimeout(() => {
            snackbar.className = '';
        }, 3000);
    }
});