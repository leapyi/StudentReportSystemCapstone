# Report Submission Website

This is the web version of the report submission Android app, converted to work with Firebase integration.

## Setup Instructions

1. **Install Dependencies:**
   ```bash
   npm install
   ```

2. **Configure Firebase:**
   - Open `index.html`
   - Replace the `firebaseConfig` object with your actual Firebase project configuration.
   - You can find this in your Firebase Console > Project Settings > General > Your apps > Web app config.

3. **Run the Application:**
   ```bash
   npm run dev
   ```
   This will start a local server at http://localhost:3000 and open it in your browser.

## Features

- Submit reports with category, description, urgency level
- Identified submission with required Student ID
- Optional email for follow-up
- ~~Image attachment upload~~ (Disabled on free Spark plan - requires paid plan)
- Real-time progress indicator for uploads (when enabled)
- Success/error notifications

## Firebase Requirements

Make sure your Firebase project has:
- Firestore enabled
- ~~Storage enabled~~ (Not required on Spark plan)
- Appropriate security rules configured (currently set to allow all for testing)

## File Structure

- `index.html` - Main HTML page
- `style.css` - Styling
- `script.js` - JavaScript logic for Firebase integration
- `package.json` - Node.js dependencies

## Notes

- The form validates required fields (category and description)
- Images are uploaded to Firebase Storage under the `images/` folder
- Reports are saved to Firestore `reports` collection
- The data structure matches the Android app's Report data class